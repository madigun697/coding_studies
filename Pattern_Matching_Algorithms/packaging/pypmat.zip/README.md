# Pypmat

Pyquibase is a Python Library to use pattern matching algorithms more easily. 

## Installation

```python
pip install pypmat
```

