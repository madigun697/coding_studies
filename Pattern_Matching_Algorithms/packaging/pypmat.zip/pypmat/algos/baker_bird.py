import queue
from . import kmp
from . import aho_corasick

def patternSearch(t, p):
    ta = []
    pa = []
    result = []

    for ti in list(map(list, zip(*t))):
        arr = list(reversed([''.join(pi) for pi in list(map(list, zip(*p)))]))
        text = ''.join(ti)
        k = len(arr)
        _, out = aho_corasick.patternSearch(arr, k, text)
        ta.append(out)

    for pi in list(map(list, zip(*p))):
        arr = list(reversed([''.join(pi) for pi in list(map(list, zip(*p)))]))
        text = ''.join(pi)
        k = len(arr)
        _, out = aho_corasick.patternSearch(arr, k, text)
        pa.append(out)
        
    for r, ti in enumerate(list(map(list, zip(*ta)))):
        
        text = ''.join([str(t) for t in ti])
        pattern = ''.join([str(p) for p in [o[-1] for o in pa]])
        
        kmp_result = kmp.patternSearch(text, pattern)
        sc = kmp_result[0] if len(kmp_result) > 0 else -1

        if sc >= 0:
            result.append([r - len(p) + 1, sc])

    return result