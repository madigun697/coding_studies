from setuptools import setup, find_packages

setup(
    name             = 'pypmat',
    version          = '0.1',
    description      = 'Python functions for pattern matching',
    author           = 'Joohyung Kyle You',
    author_email     = 'madigun697@gmail.com',
    url              = 'https://github.com/madigun697/pypmat',
    download_url     = 'https://github.com/madigun697/pypmat/archive/0.1.tar.gz',
    install_requires = [ ],
    packages         = find_packages(exclude = ['docs', 'tests*']),
    keywords         = ['pattern matching', 'kmp', 'aho-corasick', 'baker-bird'],
    python_requires  = '>=3',
    zip_safe=False,
    classifiers      = [
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.2',
        'Programming Language :: Python :: 3.3',
        'Programming Language :: Python :: 3.4',
        'Programming Language :: Python :: 3.5',
        'Programming Language :: Python :: 3.6'
    ]
)